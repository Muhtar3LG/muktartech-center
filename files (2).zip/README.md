# Muktar Tech Center — React + Tailwind Landing Page

A modern, mobile-first landing page for **Muktar Tech Center** (Computer, Mobile, Network & Digital Printing solutions, video editing, graphic design, programming/AI training, and the flagship AI-powered Learning Management System).

## Folder Structure

```
muktar-react/
├── index.html                  # Vite entry HTML
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── src/
    ├── main.jsx                # React root
    ├── App.jsx                 # Assembles all sections
    ├── index.css                # Tailwind directives + global styles
    ├── assets/
    │   └── logo.jpg             # Your brand logo
    └── components/
        ├── Navbar.jsx           # Sticky nav + mobile menu
        ├── Hero.jsx             # Hero hook + flagship LMS teaser card
        ├── ServicesGrid.jsx     # IT services + 4 training pillars (interactive cards)
        ├── EducationHub.jsx     # AI Auto-Grader / AI Animation "Innovations" section
        ├── RegistrationForm.jsx # Name / Course / Phone -> sends via WhatsApp
        ├── ContactCTA.jsx       # Telegram (@muhtartechcrnter) + phone numbers
        └── Footer.jsx
```

## Getting Started

```bash
npm install
npm run dev       # starts local dev server (usually http://localhost:5173)
npm run build      # production build -> /dist
npm run preview    # preview the production build locally
```

## Design System

| Token | Value | Use |
|---|---|---|
| `navy-deep` | `#0C2942` | Page background |
| `navy` | `#14375C` | Section surfaces |
| `navy-light` | `#1B4670` | Card gradients |
| `brand-orange` | `#EA7E2C` | Primary accent, CTAs |
| `brand-orangeSoft` | `#F5A85C` | Secondary accent, eyebrow text |

Fonts: **Fraunces** (display/headings), **Inter** (UI/body), **Noto Sans Ethiopic** (Amharic text, applied via the `.font-am` utility class).

## Things to edit before launch

1. **`src/components/RegistrationForm.jsx`** and **`src/components/ContactCTA.jsx`** — confirm the `ADMIN_WHATSAPP` number and Telegram handle (`@muhtartechcrnter`).
2. **`src/assets/logo.jpg`** — replace with a higher-resolution logo file if you have one, and add a `banner.jpg` to `src/assets/` if you'd like it used in the Hero section (send it over and it can be wired in).
3. **Copy** in `Hero.jsx` / `EducationHub.jsx` — written from your brief; adjust wording once your full Business Proposal document is available so it can be reflected more precisely.

## Notes on the AI-LMS backend advice

The Amharic architecture notes you shared (microservices, PostgreSQL + MongoDB, Python-based video-generation APIs for AI animation) describe the **backend system for your LMS product itself** — a separate application from this marketing/registration landing page. This repo is the front-facing website; the LMS would be its own service that this site can eventually link to or embed.
