import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import ServicesGrid from "./components/ServicesGrid.jsx";
import EducationHub from "./components/EducationHub.jsx";
import RegistrationForm from "./components/RegistrationForm.jsx";
import ContactCTA from "./components/ContactCTA.jsx";
import Footer from "./components/Footer.jsx";

export default function App() {
  return (
    <div className="min-h-screen bg-navy-deep">
      <Navbar />
      <Hero />
      <ServicesGrid />
      <EducationHub />
      <RegistrationForm />
      <ContactCTA />
      <Footer />
    </div>
  );
}
